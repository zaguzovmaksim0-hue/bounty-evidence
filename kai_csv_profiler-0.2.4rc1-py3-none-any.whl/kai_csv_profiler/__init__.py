"""Kai native bounded data profiler package."""
