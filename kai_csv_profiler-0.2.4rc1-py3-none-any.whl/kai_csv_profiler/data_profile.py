#!/usr/bin/env python3
"""Bounded read-only profiling for Kai-owned UTF-8 CSV, TSV, JSONL, and JSON data."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import random
import re
import stat
import sys
import unicodedata
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from itertools import chain
from pathlib import Path
from typing import TYPE_CHECKING, Any, BinaryIO

if TYPE_CHECKING:
    from collections.abc import Iterable, Iterator

REPO_ROOT = Path(__file__).resolve().parents[4]
ALLOWED_RELATIVE_ROOTS = ("data/attachments", "tmp/downloads", "tmp/extracted")
MAX_SOURCE_BYTES = 100 * 1024 * 1024
MAX_LINE_BYTES = 256 * 1024
MAX_CELL_BYTES = 16 * 1024
MAX_COLUMNS = 256
MAX_ROWS = 1_000_000
MAX_JSON_DEPTH = 20
MAX_JSON_DOCUMENT_BYTES = 16 * 1024 * 1024
MAX_JSON_TOKENS = 500_000
MAX_JSON_NUMBER_CHARS = 512
MAX_JSON_STRING_CHARS = 16 * 1024
MAX_SAMPLE_ROWS = 5
HASH_CHUNK_BYTES = 1024 * 1024
FORBIDDEN_TEXT_CONTROLS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
INTEGER_PATTERN = re.compile(r"-?(?:0|[1-9][0-9]*)\Z")
NUMBER_PATTERN = re.compile(
    r"-?(?:(?:0|[1-9][0-9]*)\.[0-9]+|(?:0|[1-9][0-9]*)[eE][+-]?[0-9]+|"
    r"(?:0|[1-9][0-9]*)\.[0-9]+[eE][+-]?[0-9]+)\Z"
)
TYPE_ORDER = {
    "boolean": 0,
    "integer": 1,
    "number": 2,
    "string": 3,
    "array": 4,
    "object": 5,
    "unknown": 6,
}


class DataProfileError(ValueError):
    """The source or tabular structure violated the bounded profiling contract."""


@dataclass
class _ColumnStats:
    name: str
    observed_types: set[str] = field(default_factory=set)
    missing_count: int = 0
    non_missing_count: int = 0

    def result(self) -> dict[str, Any]:
        observed = sorted(self.observed_types, key=lambda item: TYPE_ORDER[item])
        return {
            "name": self.name,
            "observed_types": observed or ["unknown"],
            "missing_count": self.missing_count,
            "non_missing_count": self.non_missing_count,
        }


def _allowed_roots(repo_root: Path) -> tuple[Path, ...]:
    repo = repo_root.resolve()
    return tuple((repo / relative).resolve() for relative in ALLOWED_RELATIVE_ROOTS)


def _has_symlink_component(path: Path) -> bool:
    absolute = path.absolute()
    cursor = Path(absolute.anchor)
    reparse_mask = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
    for part in absolute.parts[1:]:
        cursor /= part
        try:
            component_stat = os.lstat(cursor)
        except OSError:
            continue
        if stat.S_ISLNK(component_stat.st_mode) or bool(
            reparse_mask
            and getattr(component_stat, "st_file_attributes", 0) & reparse_mask
        ):
            return True
    return False


def _darwin_descriptor_matches_path(descriptor: int, resolved: Path) -> bool:
    """Fail closed on Darwin's vnode-derived path; never normalize an alias.

    XNU F_GETPATH requires MAXPATHLEN (PATH_MAX=1024) bytes and includes a
    terminating NUL. This supplements, not replaces, descriptor/path stat checks.
    """
    if sys.platform != "darwin":
        return False
    try:
        import fcntl

        command = getattr(fcntl, "F_GETPATH", None)
        if type(command) is not int or command != 50:
            return False
        returned = fcntl.fcntl(descriptor, command, b"\0" * 1024)
        if type(returned) is not bytes or len(returned) != 1024:
            return False
        end = returned.find(b"\0")
        if end <= 0 or any(returned[end:]):
            return False
        return returned[:end] == os.fsencode(resolved)
    except (ImportError, OSError, ValueError, UnicodeError):
        return False


def _descriptor_matches_path(
    descriptor: int,
    resolved: Path,
    descriptor_stat: os.stat_result | None = None,
) -> bool:
    current = descriptor_stat or os.fstat(descriptor)
    try:
        path_stat = os.stat(resolved, follow_symlinks=False)
    except (FileNotFoundError, OSError):
        return False
    if not (
        stat.S_ISREG(path_stat.st_mode)
        and path_stat.st_dev == current.st_dev
        and path_stat.st_ino == current.st_ino
    ):
        return False
    if sys.platform == "darwin":
        return _darwin_descriptor_matches_path(descriptor, resolved)
    if not hasattr(os, "O_NOFOLLOW"):
        return True
    try:
        descriptor_target = Path(f"/proc/self/fd/{descriptor}").resolve(strict=True)
    except (FileNotFoundError, OSError):
        return False
    return descriptor_target == resolved


def _open_source(
    path_value: str,
    *,
    repo_root: Path,
    allowed_roots: tuple[Path, ...] | None,
) -> tuple[int, Path, os.stat_result]:
    if not isinstance(path_value, str) or not path_value.strip():
        raise DataProfileError("data path must be a non-empty string")
    repo = repo_root.resolve()
    raw_path = Path(path_value)
    candidate = raw_path if raw_path.is_absolute() else repo / raw_path
    if _has_symlink_component(candidate):
        raise DataProfileError("symlink data paths are rejected")
    try:
        resolved = candidate.resolve(strict=True)
    except FileNotFoundError as exc:
        raise DataProfileError(f"data source does not exist: {path_value!r}") from exc
    roots = allowed_roots or _allowed_roots(repo)
    if not any(resolved.is_relative_to(root) for root in roots):
        raise DataProfileError(
            "data path is outside Kai-owned attachment/download/extraction areas"
        )
    flags = os.O_RDONLY
    # Nonblocking open lets fstat reject a FIFO even after a path-replacement race.
    for flag_name in ("O_CLOEXEC", "O_NOINHERIT", "O_BINARY", "O_NOFOLLOW", "O_NONBLOCK"):
        flags |= getattr(os, flag_name, 0)
    try:
        descriptor = os.open(resolved, flags)
    except OSError as exc:
        raise DataProfileError("data path must name a stable regular file") from exc
    try:
        source_stat = os.fstat(descriptor)
        if not stat.S_ISREG(source_stat.st_mode):
            raise DataProfileError("data path must name a regular file")
        if not _descriptor_matches_path(descriptor, resolved, source_stat) or (
            not any(resolved.is_relative_to(root) for root in roots)
            or _has_symlink_component(candidate)
        ):
            raise DataProfileError("data source changed while it was being opened")
        if source_stat.st_size <= 0:
            raise DataProfileError("data source is empty")
        if source_stat.st_size > MAX_SOURCE_BYTES:
            raise DataProfileError(f"data source exceeds {MAX_SOURCE_BYTES} bytes")
    except Exception:
        os.close(descriptor)
        raise
    return descriptor, resolved, source_stat


def _source_is_unchanged(
    descriptor: int,
    original: os.stat_result,
    resolved: Path | None = None,
) -> bool:
    current = os.fstat(descriptor)
    unchanged = (
        current.st_dev == original.st_dev
        and current.st_ino == original.st_ino
        and current.st_size == original.st_size
        and current.st_mtime_ns == original.st_mtime_ns
        and current.st_ctime_ns == original.st_ctime_ns
    )
    if not unchanged or resolved is None:
        return unchanged
    return _descriptor_matches_path(descriptor, resolved, current)


def _hash_source(descriptor: int) -> str:
    digest = hashlib.sha256()
    os.lseek(descriptor, 0, os.SEEK_SET)
    while chunk := os.read(descriptor, HASH_CHUNK_BYTES):
        digest.update(chunk)
    os.lseek(descriptor, 0, os.SEEK_SET)
    return digest.hexdigest()


def _bounded_text_lines(source: BinaryIO) -> Iterator[tuple[int, str, bool, str]]:
    line_number = 0
    first = True
    while True:
        raw = source.readline(MAX_LINE_BYTES + 1)
        if not raw:
            break
        line_number += 1
        if len(raw) > MAX_LINE_BYTES:
            raise DataProfileError(
                f"physical line exceeds {MAX_LINE_BYTES} bytes at line {line_number}"
            )
        try:
            text = raw.decode("utf-8", errors="strict")
        except UnicodeDecodeError as exc:
            raise DataProfileError(
                f"data source is not strict UTF-8 at line {line_number}"
            ) from exc
        had_bom = first and text.startswith("\ufeff")
        if had_bom:
            text = text.removeprefix("\ufeff")
        first = False
        line_ending = ""
        if text.endswith("\r\n"):
            text = text[:-2]
            line_ending = "\r\n"
        elif text.endswith("\n"):
            text = text[:-1]
            line_ending = "\n"
        if "\r" in text or FORBIDDEN_TEXT_CONTROLS.search(text):
            raise DataProfileError(f"binary control character found at line {line_number}")
        yield line_number, text, had_bom, line_ending


@dataclass
class _CsvQuoteState:
    in_quotes: bool = False
    at_field_start: bool = True
    just_closed_quote: bool = False


def _advance_csv_quote_state(
    text: str,
    delimiter: str,
    *,
    line_number: int,
    state: _CsvQuoteState,
) -> None:
    index = 0
    while index < len(text):
        character = text[index]
        if state.in_quotes:
            if character == '"':
                if index + 1 < len(text) and text[index + 1] == '"':
                    index += 2
                    continue
                state.in_quotes = False
                state.just_closed_quote = True
            index += 1
            continue
        if character == delimiter:
            state.at_field_start = True
            state.just_closed_quote = False
        elif character == '"':
            if not state.at_field_start or state.just_closed_quote:
                raise DataProfileError(f"malformed CSV quoting at line {line_number}")
            state.in_quotes = True
            state.at_field_start = False
        else:
            if state.just_closed_quote:
                raise DataProfileError(f"malformed CSV quoting at line {line_number}")
            state.at_field_start = False
        index += 1


def _validate_csv_quotes(text: str, delimiter: str, *, line_number: int) -> None:
    state = _CsvQuoteState()
    _advance_csv_quote_state(text, delimiter, line_number=line_number, state=state)
    if state.in_quotes:
        raise DataProfileError(f"malformed CSV quoting at line {line_number}")


def _bounded_csv_header(
    first: tuple[int, str, bool, str],
    lines: Iterator[tuple[int, str, bool, str]],
) -> tuple[int, str, bool, str]:
    start_line, first_text, had_bom, first_line_ending = first
    parts = [first_text]
    record_bytes = len(first_text.encode("utf-8"))
    in_quotes = False
    previous_line_ending = first_line_ending
    for line_number, text, _line_bom, line_ending in chain((first,), lines):
        if line_number != start_line:
            parts.extend((previous_line_ending, text))
            record_bytes += len(previous_line_ending) + len(text.encode("utf-8"))
        if record_bytes > MAX_LINE_BYTES:
            raise DataProfileError(
                f"logical CSV record exceeds {MAX_LINE_BYTES} bytes at line {start_line}"
            )
        index = 0
        while index < len(text):
            if text[index] == '"':
                if in_quotes and index + 1 < len(text) and text[index + 1] == '"':
                    index += 2
                    continue
                in_quotes = not in_quotes
            index += 1
        previous_line_ending = line_ending
        if not in_quotes:
            return start_line, "".join(parts), had_bom, ""
    raise DataProfileError(f"malformed CSV quoting at line {start_line}")


def _bounded_csv_records(
    lines: Iterable[tuple[int, str, bool, str]], delimiter: str
) -> Iterator[tuple[int, str, bool]]:
    parts: list[str] = []
    state = _CsvQuoteState()
    start_line = 0
    last_line = 0
    had_bom = False
    previous_line_ending = ""
    record_bytes = 0
    for line_number, text, line_bom, line_ending in lines:
        if not parts:
            start_line = line_number
            had_bom = line_bom
            state = _CsvQuoteState()
        if not text and not state.in_quotes:
            raise DataProfileError(f"blank row is rejected at line {line_number}")
        if parts:
            parts.append(previous_line_ending)
            record_bytes += len(previous_line_ending)
        parts.append(text)
        record_bytes += len(text.encode("utf-8"))
        if record_bytes > MAX_LINE_BYTES:
            raise DataProfileError(
                f"logical CSV record exceeds {MAX_LINE_BYTES} bytes at line {start_line}"
            )
        _advance_csv_quote_state(text, delimiter, line_number=line_number, state=state)
        last_line = line_number
        previous_line_ending = line_ending
        if state.in_quotes:
            continue
        yield start_line, "".join(parts), had_bom
        parts = []
        record_bytes = 0
    if parts:
        raise DataProfileError(f"malformed CSV quoting at line {last_line}")


def _parse_csv_line(text: str, delimiter: str, *, line_number: int) -> list[str]:
    _validate_csv_quotes(text, delimiter, line_number=line_number)
    try:
        row = next(csv.reader([text], delimiter=delimiter, strict=True))
    except (csv.Error, StopIteration) as exc:
        raise DataProfileError(f"malformed CSV record at line {line_number}") from exc
    return row


def _detect_delimiter(header: str) -> str:
    parsed: dict[str, list[str]] = {}
    for delimiter in (",", "\t"):
        try:
            row = _parse_csv_line(header, delimiter, line_number=1)
        except DataProfileError:
            continue
        if len(row) > 1:
            parsed[delimiter] = row
    if len(parsed) != 1:
        raise DataProfileError("could not unambiguously detect CSV, TSV, or JSONL format")
    return next(iter(parsed))


def _cell_bytes(value: str, *, line_number: int) -> int:
    try:
        size = len(value.encode("utf-8"))
    except UnicodeEncodeError as exc:
        raise DataProfileError(f"cell is not valid UTF-8 at line {line_number}") from exc
    if size > MAX_CELL_BYTES:
        raise DataProfileError(f"cell exceeds {MAX_CELL_BYTES} bytes at line {line_number}")
    if FORBIDDEN_TEXT_CONTROLS.search(value):
        raise DataProfileError(f"binary control character found at line {line_number}")
    return size


def _validate_columns(columns: list[str], *, line_number: int) -> None:
    if not columns or len(columns) > MAX_COLUMNS:
        raise DataProfileError(f"column count exceeds {MAX_COLUMNS} at line {line_number}")
    seen: set[str] = set()
    collisions: dict[str, str] = {}
    for name in columns:
        _cell_bytes(name, line_number=line_number)
        if not name.strip():
            raise DataProfileError(f"empty column name at line {line_number}")
        if name in seen:
            raise DataProfileError(f"duplicate column name: {name!r}")
        key = unicodedata.normalize("NFC", name).casefold()
        if key in collisions:
            raise DataProfileError(f"colliding column names: {collisions[key]!r}, {name!r}")
        seen.add(name)
        collisions[key] = name


def _csv_scalar_type(value: str) -> str:
    lowered = value.casefold()
    if lowered in {"true", "false"}:
        return "boolean"
    if INTEGER_PATTERN.fullmatch(value):
        return "integer"
    if NUMBER_PATTERN.fullmatch(value):
        try:
            number = Decimal(value)
        except InvalidOperation:
            return "string"
        if number.is_finite():
            return "number"
    return "string"


def _json_document_preflight(text: str) -> None:
    """Bound JSON allocations lexically before json.loads materializes a document."""
    stack: list[list[Any]] = []
    in_string = False
    escaped = False
    string_chars = 0
    number_chars = 0
    tokens = 0
    for character in text:
        if in_string:
            if not escaped and character == '"':
                in_string = False
                continue
            string_chars += 1
            if string_chars > MAX_JSON_STRING_CHARS:
                raise DataProfileError("JSON string exceeds the bounded document contract")
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            continue
        if character == '"':
            in_string = True
            string_chars = 0
            number_chars = 0
            continue
        if character in "-+0123456789.eE":
            number_chars += 1
            if number_chars > MAX_JSON_NUMBER_CHARS:
                raise DataProfileError("JSON number exceeds the bounded document contract")
        else:
            number_chars = 0
        if character in "[{":
            tokens += 1
            stack.append([character, 0])
            if len(stack) > MAX_JSON_DEPTH:
                raise DataProfileError(
                    f"JSON nesting depth exceeds {MAX_JSON_DEPTH} in document"
                )
        elif character in "]}":
            tokens += 1
            expected = "[" if character == "]" else "{"
            if not stack or stack[-1][0] != expected:
                raise DataProfileError("malformed JSON container structure")
            stack.pop()
        elif character == "," and stack:
            tokens += 1
            stack[-1][1] += 1
            limit = MAX_ROWS if stack[-1][0] == "[" else MAX_COLUMNS
            if stack[-1][1] >= limit:
                kind = "array items" if stack[-1][0] == "[" else "object members"
                raise DataProfileError(f"JSON {kind} exceed the bounded document contract")
        elif character == ":":
            tokens += 1
        if tokens > MAX_JSON_TOKENS:
            raise DataProfileError("JSON structural token count exceeds the bounded document contract")
    if in_string or stack:
        raise DataProfileError("malformed or incomplete JSON document structure")


def _bounded_json_int(value: str) -> int:
    if len(value.lstrip("-")) > MAX_JSON_NUMBER_CHARS:
        raise DataProfileError("JSON integer exceeds the bounded document contract")
    return int(value)


def _load_json_document(
    source: BinaryIO,
    *,
    record_key: str | None,
    parse_float: Any = float,
) -> tuple[list[dict[str, Any]], bool]:
    if record_key is not None and (
        not isinstance(record_key, str) or not record_key.strip()
    ):
        raise DataProfileError("record_key must be a non-empty exact top-level key")
    payload = source.read(MAX_JSON_DOCUMENT_BYTES + 1)
    if len(payload) > MAX_JSON_DOCUMENT_BYTES:
        raise DataProfileError(f"JSON document exceeds {MAX_JSON_DOCUMENT_BYTES} bytes")
    had_bom = payload.startswith(b"\xef\xbb\xbf")
    if had_bom:
        payload = payload[3:]
    try:
        text = payload.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise DataProfileError("JSON document is not strict UTF-8") from exc
    if not text.strip():
        raise DataProfileError("JSON document is empty")
    _json_document_preflight(text)
    try:
        value = json.loads(
            text,
            object_pairs_hook=_unique_json_object,
            parse_constant=_reject_json_constant,
            parse_float=parse_float,
            parse_int=_bounded_json_int,
        )
    except DataProfileError:
        raise
    except (json.JSONDecodeError, RecursionError, ValueError, InvalidOperation) as exc:
        raise DataProfileError("malformed JSON document") from exc
    if record_key is None:
        if not isinstance(value, list):
            raise DataProfileError("JSON document must be a top-level array or name record_key")
        rows = value
    else:
        _cell_bytes(record_key, line_number=1)
        if not isinstance(value, dict) or record_key not in value:
            raise DataProfileError("record_key is not an exact top-level JSON key")
        rows = value[record_key]
        if not isinstance(rows, list):
            raise DataProfileError("record_key must name a top-level JSON array")
    if not rows:
        raise DataProfileError("JSON record array is empty")
    if len(rows) > MAX_ROWS:
        raise DataProfileError(f"data row count exceeds {MAX_ROWS}")
    if any(not isinstance(row, dict) for row in rows):
        raise DataProfileError("JSON record array rows must all be JSON objects")
    return rows, had_bom


def _reject_json_constant(value: str) -> Any:
    raise DataProfileError(f"non-finite JSON constant is rejected: {value}")


def _unique_json_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise DataProfileError(f"duplicate JSON key is rejected: {key!r}")
        result[key] = value
    return result


def _json_cell_type(value: Any, *, line_number: int) -> str:
    if isinstance(value, bool):
        result = "boolean"
    elif isinstance(value, int):
        result = "integer"
    elif isinstance(value, float):
        if not math.isfinite(value):
            raise DataProfileError(f"non-finite JSON number at line {line_number}")
        result = "number"
    elif isinstance(value, str):
        result = "string"
    elif isinstance(value, list):
        result = "array"
    elif isinstance(value, dict):
        result = "object"
    else:
        raise DataProfileError(f"unsupported JSON cell type at line {line_number}")
    try:
        encoded = json.dumps(
            value, ensure_ascii=False, allow_nan=False, separators=(",", ":")
        ).encode("utf-8")
    except (UnicodeEncodeError, ValueError, TypeError) as exc:
        raise DataProfileError(
            f"JSON cell is not bounded valid UTF-8 at line {line_number}"
        ) from exc
    if len(encoded) > MAX_CELL_BYTES:
        raise DataProfileError(f"cell exceeds {MAX_CELL_BYTES} bytes at line {line_number}")
    return result


def _reservoir_add(
    sample: list[dict[str, Any]],
    row: dict[str, Any],
    *,
    row_number: int,
    rng: random.Random,
) -> None:
    item = {"row_number": row_number, "values": row}
    if len(sample) < MAX_SAMPLE_ROWS:
        sample.append(item)
        return
    slot = rng.randrange(row_number)
    if slot < MAX_SAMPLE_ROWS:
        sample[slot] = item


def _profile_csv(
    lines: Iterable[tuple[int, str, bool, str]],
    *,
    first: tuple[int, str, bool, str],
    delimiter: str,
    rng: random.Random,
) -> tuple[list[_ColumnStats], int, list[dict[str, Any]], bool]:
    header_line, header_text, had_bom, _header_line_ending = first
    columns = _parse_csv_line(header_text, delimiter, line_number=header_line)
    _validate_columns(columns, line_number=header_line)
    stats = [_ColumnStats(name) for name in columns]
    sample: list[dict[str, Any]] = []
    row_count = 0
    for line_number, text, _line_bom in _bounded_csv_records(lines, delimiter):
        row = _parse_csv_line(text, delimiter, line_number=line_number)
        if len(row) != len(columns):
            raise DataProfileError(
                f"CSV row width mismatch at line {line_number}: "
                f"expected {len(columns)}, got {len(row)}"
            )
        row_count += 1
        if row_count > MAX_ROWS:
            raise DataProfileError(f"data row count exceeds {MAX_ROWS}")
        values: dict[str, str] = {}
        for column, value, column_stats in zip(columns, row, stats, strict=True):
            _cell_bytes(value, line_number=line_number)
            values[column] = value
            if value == "":
                column_stats.missing_count += 1
            else:
                column_stats.non_missing_count += 1
                column_stats.observed_types.add(_csv_scalar_type(value))
        _reservoir_add(sample, values, row_number=row_count, rng=rng)
    sample.sort(key=lambda item: item["row_number"])
    return stats, row_count, sample, had_bom


def _parse_json_object(text: str, *, line_number: int) -> dict[str, Any]:
    if not text:
        raise DataProfileError(f"blank row is rejected at line {line_number}")
    _json_document_preflight(text)
    try:
        value = json.loads(
            text,
            object_pairs_hook=_unique_json_object,
            parse_constant=_reject_json_constant,
        )
    except DataProfileError:
        raise
    except (json.JSONDecodeError, RecursionError, ValueError) as exc:
        raise DataProfileError(f"malformed JSONL record at line {line_number}") from exc
    if not isinstance(value, dict):
        raise DataProfileError(f"JSONL row must be a JSON object at line {line_number}")
    return value


def _profile_json_rows(
    rows: Iterable[tuple[int, dict[str, Any]]],
    *,
    rng: random.Random,
    had_bom: bool,
) -> tuple[list[_ColumnStats], int, list[dict[str, Any]], bool]:
    stats: list[_ColumnStats] = []
    by_name: dict[str, _ColumnStats] = {}
    collision_names: dict[str, str] = {}
    sample: list[dict[str, Any]] = []
    row_count = 0
    for source_position, row in rows:
        row_count += 1
        if row_count > MAX_ROWS:
            raise DataProfileError(f"data row count exceeds {MAX_ROWS}")
        for name in row:
            if not isinstance(name, str) or not name.strip():
                raise DataProfileError(f"empty column name at row {source_position}")
            _cell_bytes(name, line_number=source_position)
            collision_key = unicodedata.normalize("NFC", name).casefold()
            prior = collision_names.get(collision_key)
            if prior is not None and prior != name:
                raise DataProfileError(f"colliding column names: {prior!r}, {name!r}")
            if name not in by_name:
                if len(stats) >= MAX_COLUMNS:
                    raise DataProfileError(
                        f"column count exceeds {MAX_COLUMNS} at row {source_position}"
                    )
                column_stats = _ColumnStats(name=name, missing_count=row_count - 1)
                stats.append(column_stats)
                by_name[name] = column_stats
                collision_names[collision_key] = name
        for column_stats in stats:
            if column_stats.name not in row or row[column_stats.name] is None:
                column_stats.missing_count += 1
                continue
            column_stats.non_missing_count += 1
            column_stats.observed_types.add(
                _json_cell_type(row[column_stats.name], line_number=source_position)
            )
        _reservoir_add(sample, row, row_number=row_count, rng=rng)
    sample.sort(key=lambda item: item["row_number"])
    return stats, row_count, sample, had_bom


def _profile_jsonl(
    lines: Iterable[tuple[int, str, bool, str]],
    *,
    first: tuple[int, str, bool, str],
    rng: random.Random,
) -> tuple[list[_ColumnStats], int, list[dict[str, Any]], bool]:
    parsed_rows = (
        (line_number, _parse_json_object(text, line_number=line_number))
        for line_number, text, _line_bom, _line_ending in chain((first,), lines)
    )
    return _profile_json_rows(parsed_rows, rng=rng, had_bom=first[2])


def profile_data(
    path: str,
    *,
    record_key: str | None = None,
    repo_root: Path = REPO_ROOT,
    allowed_roots: tuple[Path, ...] | None = None,
) -> dict[str, Any]:
    """Return a bounded profile of one UTF-8 CSV/TSV/JSONL/JSON source."""
    descriptor, resolved, source_stat = _open_source(
        path, repo_root=repo_root, allowed_roots=allowed_roots
    )
    try:
        source_sha256 = _hash_source(descriptor)
        if not _source_is_unchanged(descriptor, source_stat, resolved):
            raise DataProfileError("data source changed while it was being hashed")
        rng = random.Random(int(source_sha256[:16], 16))
        os.lseek(descriptor, 0, os.SEEK_SET)
        with os.fdopen(os.dup(descriptor), "rb") as source:
            prefix = source.read(4096)
            source.seek(0)
            without_bom = prefix.removeprefix(b"\xef\xbb\xbf").lstrip()
            if record_key is not None or without_bom.startswith(b"["):
                rows, had_bom = _load_json_document(source, record_key=record_key)
                data_format = "json"
                delimiter: str | None = None
                stats, row_count, sample, had_bom = _profile_json_rows(
                    enumerate(rows, start=1), rng=rng, had_bom=had_bom
                )
            else:
                line_iterator = _bounded_text_lines(source)
                try:
                    first = next(line_iterator)
                except StopIteration as exc:
                    raise DataProfileError("data source is empty") from exc
                if not first[1]:
                    raise DataProfileError(f"blank row is rejected at line {first[0]}")
                if first[1].lstrip().startswith(("{", "[")):
                    data_format = "jsonl"
                    delimiter = None
                    stats, row_count, sample, had_bom = _profile_jsonl(
                        line_iterator, first=first, rng=rng
                    )
                else:
                    first = _bounded_csv_header(first, line_iterator)
                    delimiter = _detect_delimiter(first[1])
                    data_format = "tsv" if delimiter == "\t" else "csv"
                    stats, row_count, sample, had_bom = _profile_csv(
                        line_iterator, first=first, delimiter=delimiter, rng=rng
                    )
        if not _source_is_unchanged(descriptor, source_stat, resolved):
            raise DataProfileError("data source changed while it was being profiled")
        return {
            "status": "ok",
            "path": resolved.relative_to(repo_root.resolve()).as_posix(),
            "format": data_format,
            "delimiter": delimiter,
            "record_key": record_key if data_format == "json" else None,
            "encoding": "utf-8",
            "utf8_bom": had_bom,
            "source_bytes": source_stat.st_size,
            "source_sha256": source_sha256,
            "row_count": row_count,
            "column_count": len(stats),
            "columns": [column.result() for column in stats],
            "sample_strategy": "deterministic_reservoir",
            "sample_rows": sample,
            "max_rows": MAX_ROWS,
            "max_columns": MAX_COLUMNS,
            "max_line_bytes": MAX_LINE_BYTES,
            "max_cell_bytes": MAX_CELL_BYTES,
            "max_json_depth": MAX_JSON_DEPTH,
            "max_json_document_bytes": MAX_JSON_DOCUMENT_BYTES,
            "truncated": False,
        }
    except DataProfileError:
        raise
    except OSError as exc:
        raise DataProfileError(f"data source read failed: {type(exc).__name__}") from exc
    finally:
        os.close(descriptor)


def handler(args: dict[str, Any], base_dir: Path, identity: str) -> str:
    """Native tool handler."""
    del identity
    if base_dir.resolve() != REPO_ROOT:
        raise DataProfileError(f"data_profile is restricted to {REPO_ROOT}")
    return json.dumps(
        profile_data(args.get("path", ""), record_key=args.get("record_key")),
        ensure_ascii=False,
        indent=2,
    )
